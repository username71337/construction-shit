﻿namespace Go_ConstructionProjects.Models
{
    public class Projects
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public string? Type { get; set; }
        public string? Description { get; set; }
        public string? Location { get; set; }
        public string? Budget { get; set; }
    }
}
