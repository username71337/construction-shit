﻿namespace Go_ConstructionProjects.Models
{
    public class Materials
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public string? Dimension { get; set; }
        public string? Price { get; set; }
    }
}
