﻿using Go_ConstructionProjects.Models;
using Microsoft.EntityFrameworkCore;

namespace Go_ConstructionProjects.Data
{
    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions<DataContext> options)
            : base(options)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Materials>().HasData(
                
                new Materials { Id = 1, Name = "Wood", Description = "Wood abc", Dimension = "15 x 50 x 55 in.", Price = "500" }
                
                );

            modelBuilder.Entity<Projects>().HasData(

                new Projects { Id = 1, Name = "House abc", Type = "House", Description = "House for the people", Location = "North Korea", Budget = "500000" }

                );
        }

        public DbSet<Materials> Materials { get; set; }
        public DbSet<Projects> Projects { get; set; }
    }
}
