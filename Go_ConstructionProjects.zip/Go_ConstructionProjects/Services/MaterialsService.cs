﻿using Go_ConstructionProjects.Data;
using Go_ConstructionProjects.Models;
using Microsoft.EntityFrameworkCore;



namespace Go_ConstructionProjects.Services
{
    public class MaterialsService: IMaterialsService
    {
        private readonly DataContext _context;
        public MaterialsService(DataContext context)
        {
            _context = context;
        }

        public async Task AddMaterialsAsync(Materials materials)
        {
            _context.Materials.Add(materials);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteMaterialsAsync(int id)
        {
            var material = await _context.Materials.FindAsync(id);
            if (material != null)
            {
                _context.Materials.Remove(material);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<List<Materials>> GetAllMaterialsAsync()
        {
            var result = await _context.Materials.ToListAsync();
            return result;
        }

        public async Task<Materials> GetMaterialsByIdAsync(int id)
        {
            var material = await _context.Materials.FindAsync(id);
            return material;
        }

        public async Task UpdateMaterialsAsync(Materials materials, int id)
        {
            var dbMaterial = await _context.Materials.FindAsync(id);
            if (materials != null)
            {
                dbMaterial.Name = materials.Name;
                dbMaterial.Description = materials.Description;
                dbMaterial.Dimension = materials.Dimension;
                dbMaterial.Price = materials.Price;
                await _context.SaveChangesAsync();
            }
        }
    }
}
