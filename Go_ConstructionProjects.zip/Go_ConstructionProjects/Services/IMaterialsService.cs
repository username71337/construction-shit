﻿using System.Threading.Tasks;
using Go_ConstructionProjects.Models;

namespace Go_ConstructionProjects.Services
{
    public interface IMaterialsService
    {
        Task<List<Materials>> GetAllMaterialsAsync();
        Task<Materials> GetMaterialsByIdAsync(int id);
        Task AddMaterialsAsync(Materials materials);
        Task UpdateMaterialsAsync(Materials materials, int id);
        Task DeleteMaterialsAsync(int id);
    }
}
