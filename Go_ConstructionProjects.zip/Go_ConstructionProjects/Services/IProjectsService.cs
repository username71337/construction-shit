﻿using Go_ConstructionProjects.Models;

namespace Go_ConstructionProjects.Services
{
    public interface IProjectsService
    {
        Task<List<Projects>> GetAllProjectsAsync();
        Task<Projects> GetProjectsByIdAsync(int id);
        Task AddProjectsAsync(Projects project);
        Task UpdateProjectsAsync(Projects project, int id);
        Task DeleteProjectsAsync(int id);

    }
}
